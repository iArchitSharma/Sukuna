import { VersionTable } from '@/components/versionTable';
import { useState } from 'react';

export default function Accordion() {

  return (
    <div><h2 className="mb-10 sm:mb-20 text-xl text-center sm:text-5xl dark:text-white text-black">
    Ask Aceternity UI Anything
  </h2></div>
  );
}
